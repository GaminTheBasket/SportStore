using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShopTheThao.Data;
using ShopTheThao.Models;
using Microsoft.AspNetCore.Authorization;

namespace ShopTheThao.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OrdersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Orders/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Orders/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerName,CustomerEmail,CustomerPhone,ShippingAddress,Note")] Order order)
        {
            if (ModelState.IsValid)
            {
                // Lấy giỏ hàng từ Session
                var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("CartSession");
                if (cart == null || !cart.Any())
                {
                    ModelState.AddModelError("", "Giỏ hàng trống!");
                    return View(order);
                }

                // Kiểm tra tồn kho
                foreach (var item in cart)
                {
                    var product = await _context.Products.FindAsync(item.ProductId);
                    if (product == null || product.StockQuantity < item.Quantity)
                    {
                        ModelState.AddModelError("", $"Sản phẩm '{item.ProductName}' không đủ số lượng trong kho.");
                        return View(order);
                    }
                }

                order.OrderDate = DateTime.Now;
                order.Status = "Pending";
                order.TotalAmount = cart.Sum(x => x.UnitPrice * x.Quantity);

                _context.Add(order);
                await _context.SaveChangesAsync();

                // Lưu chi tiết đơn hàng và cập nhật tồn kho
                foreach (var item in cart)
                {
                    var product = await _context.Products.FindAsync(item.ProductId);
                    if (product != null)
                    {
                        product.StockQuantity -= item.Quantity;
                    }
                    var orderDetail = new OrderDetail
                    {
                        OrderId = order.Id,
                        ProductId = item.ProductId,
                        Quantity = item.Quantity,
                        UnitPrice = item.UnitPrice,
                        TotalPrice = item.UnitPrice * item.Quantity
                    };
                    _context.OrderDetails.Add(orderDetail);
                }
                await _context.SaveChangesAsync();

                // Xóa giỏ hàng sau khi đặt hàng thành công
                HttpContext.Session.Remove("CartSession");

                return RedirectToAction("Confirmation", new { id = order.Id });
            }
            return View(order);
        }

        // GET: Orders/Confirmation/5
        public async Task<IActionResult> Confirmation(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Product)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

        // GET: Orders/Track
        public IActionResult Track()
        {
            return View();
        }

        // POST: Orders/Track
        [HttpPost]
        public async Task<IActionResult> Track(string email, string phone)
        {
            var order = await _context.Orders
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Product)
                .FirstOrDefaultAsync(o => o.CustomerEmail == email && o.CustomerPhone == phone);

            if (order == null)
            {
                ViewBag.Message = "Không tìm thấy đơn hàng với thông tin đã cung cấp.";
                return View();
            }

            return View("OrderStatus", order);
        }
    }
} 