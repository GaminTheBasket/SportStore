namespace ShopTheThao.Models
{
    public class CategoryStatViewModel
    {
        public int Quantity { get; set; }
        public decimal Revenue { get; set; }
    }
} 