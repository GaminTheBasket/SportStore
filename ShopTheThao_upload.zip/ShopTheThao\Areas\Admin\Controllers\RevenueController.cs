using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShopTheThao.Models;
using ShopTheThao.Data;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ShopTheThao.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class RevenueController : Controller
    {
        private readonly ApplicationDbContext _context;
        public RevenueController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(DateTime? startDate, DateTime? endDate, int? categoryId)
        {
            var query = _context.OrderDetails
                .Include(od => od.Product).ThenInclude(p => p.Category)
                .Include(od => od.Order)
                .AsQueryable();

            if (startDate.HasValue)
            {
                query = query.Where(od => od.Order.OrderDate >= startDate.Value);
            }
            if (endDate.HasValue)
            {
                query = query.Where(od => od.Order.OrderDate <= endDate.Value);
            }
            if (categoryId.HasValue && categoryId.Value > 0)
            {
                query = query.Where(od => od.Product.CategoryId == categoryId.Value);
            }

            var revenueList = await query
                .GroupBy(od => new { od.ProductId, od.Product.Name, CategoryName = od.Product.Category.Name, od.UnitPrice })
                .Select(g => new RevenueProductViewModel
                {
                    ProductId = g.Key.ProductId,
                    ProductName = g.Key.Name,
                    CategoryName = g.Key.CategoryName,
                    QuantitySold = g.Sum(x => x.Quantity),
                    UnitPrice = g.Key.UnitPrice,
                    TotalRevenue = g.Sum(x => x.Quantity * x.UnitPrice)
                })
                .OrderByDescending(x => x.TotalRevenue)
                .ToListAsync();

            // Thống kê tổng số lượng đã bán, tổng doanh thu, danh mục bán chạy nhất
            int totalQuantity = revenueList.Sum(x => x.QuantitySold);
            decimal totalRevenue = revenueList.Sum(x => x.TotalRevenue);
            var topCategory = revenueList
                .GroupBy(x => x.CategoryName)
                .Select(g => new { Category = g.Key, Quantity = g.Sum(x => x.QuantitySold) })
                .OrderByDescending(g => g.Quantity)
                .FirstOrDefault();
            string topCategoryName = topCategory?.Category ?? "Không có dữ liệu";
            int topCategoryQuantity = topCategory?.Quantity ?? 0;

            // Thống kê cho từng danh mục
            var categoryStats = revenueList
                .GroupBy(x => x.CategoryName)
                .ToDictionary(
                    g => g.Key,
                    g => new ShopTheThao.Models.CategoryStatViewModel {
                        Quantity = g.Sum(x => x.QuantitySold),
                        Revenue = g.Sum(x => x.TotalRevenue)
                    }
                );

            ViewBag.TotalQuantity = totalQuantity;
            ViewBag.TotalRevenue = totalRevenue;
            ViewBag.TopCategory = topCategoryName;
            ViewBag.TopCategoryQuantity = topCategoryQuantity;
            ViewBag.CategoryStats = categoryStats;

            var categories = await _context.Categories.Where(c => c.IsActive).ToListAsync();
            ViewBag.Categories = categories;
            ViewBag.SelectedCategory = categoryId;
            ViewBag.StartDate = startDate?.ToString("yyyy-MM-dd");
            ViewBag.EndDate = endDate?.ToString("yyyy-MM-dd");

            return View(revenueList);
        }
    }
} 