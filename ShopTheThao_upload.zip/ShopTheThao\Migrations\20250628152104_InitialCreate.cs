﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ShopTheThao.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CustomerEmail = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    CustomerPhone = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    ShippingAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Note = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    TotalAmount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    OrderDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ShippedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeliveredDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    DiscountPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    StockQuantity = table.Column<int>(type: "int", nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Brand = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Size = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Color = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsFeatured = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CategoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Products_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "OrderDetails",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderId = table.Column<int>(type: "int", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    UnitPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderDetails", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderDetails_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OrderDetails_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "CreatedAt", "Description", "ImageUrl", "IsActive", "Name" },
                values: new object[,]
                {
                    { 1, new DateTime(2025, 6, 28, 22, 21, 4, 686, DateTimeKind.Local).AddTicks(8395), "Các loại giày thể thao chất lượng cao", "/images/categories/shoes.jpg", true, "Giày thể thao" },
                    { 2, new DateTime(2025, 6, 28, 22, 21, 4, 686, DateTimeKind.Local).AddTicks(8414), "Quần áo thể thao thoải mái, thấm hút mồ hôi", "/images/categories/clothing.jpg", true, "Quần áo thể thao" },
                    { 3, new DateTime(2025, 6, 28, 22, 21, 4, 686, DateTimeKind.Local).AddTicks(8415), "Phụ kiện hỗ trợ tập luyện", "/images/categories/accessories.jpg", true, "Phụ kiện thể thao" },
                    { 4, new DateTime(2025, 6, 28, 22, 21, 4, 686, DateTimeKind.Local).AddTicks(8416), "Dụng cụ tập luyện chuyên nghiệp", "/images/categories/equipment.jpg", true, "Dụng cụ thể thao" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "Brand", "CategoryId", "Color", "CreatedAt", "Description", "DiscountPrice", "ImageUrl", "IsActive", "IsFeatured", "Name", "Price", "Size", "StockQuantity", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, "Nike", 1, "Đen/Trắng", new DateTime(2025, 6, 28, 22, 21, 4, 686, DateTimeKind.Local).AddTicks(8558), "Giày thể thao Nike Air Max 270 với công nghệ Air Max độc đáo, thoải mái và phong cách", 2200000m, "/images/products/nike-air-max-270.jpg", true, true, "Giày Nike Air Max 270", 2500000m, "40-45", 50, null },
                    { 2, "Adidas", 2, "Xanh dương", new DateTime(2025, 6, 28, 22, 21, 4, 686, DateTimeKind.Local).AddTicks(8577), "Áo thun thể thao Adidas với chất liệu thấm hút mồ hôi, thoải mái khi vận động", 380000m, "/images/products/adidas-tshirt.jpg", true, true, "Áo thun thể thao Adidas", 450000m, "S-XXL", 100, null },
                    { 3, "Puma", 2, "Đen", new DateTime(2025, 6, 28, 22, 21, 4, 686, DateTimeKind.Local).AddTicks(8593), "Quần short thể thao Puma với thiết kế thoải mái, phù hợp cho nhiều môn thể thao", null, "/images/products/puma-shorts.jpg", true, false, "Quần short thể thao Puma", 350000m, "S-XXL", 75, null },
                    { 4, "Nike", 4, "Trắng/Đen", new DateTime(2025, 6, 28, 22, 21, 4, 686, DateTimeKind.Local).AddTicks(8595), "Bóng đá chính thức chất lượng cao, phù hợp cho thi đấu và tập luyện", 650000m, "/images/products/football.jpg", true, false, "Bóng đá chính thức", 800000m, "Size 5", 30, null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_OrderDetails_OrderId",
                table: "OrderDetails",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderDetails_ProductId",
                table: "OrderDetails",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_CategoryId",
                table: "Products",
                column: "CategoryId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OrderDetails");

            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
