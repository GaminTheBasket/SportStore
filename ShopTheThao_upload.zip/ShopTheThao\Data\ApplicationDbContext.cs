using Microsoft.EntityFrameworkCore;
using ShopTheThao.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace ShopTheThao.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure relationships
            modelBuilder.Entity<Product>()
                .HasOne(p => p.Category)
                .WithMany(c => c.Products)
                .HasForeignKey(p => p.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<OrderDetail>()
                .HasOne(od => od.Order)
                .WithMany(o => o.OrderDetails)
                .HasForeignKey(od => od.OrderId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<OrderDetail>()
                .HasOne(od => od.Product)
                .WithMany(p => p.OrderDetails)
                .HasForeignKey(od => od.ProductId)
                .OnDelete(DeleteBehavior.Restrict);

            // Seed data
            SeedData(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            // Seed Categories
            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1, Name = "Giày thể thao", Description = "Các loại giày thể thao chất lượng cao", ImageUrl = "/images/categories/shoes.jpg" },
                new Category { Id = 2, Name = "Quần áo thể thao", Description = "Quần áo thể thao thoải mái, thấm hút mồ hôi", ImageUrl = "/images/categories/clothing.jpg" },
                new Category { Id = 3, Name = "Phụ kiện thể thao", Description = "Phụ kiện hỗ trợ tập luyện", ImageUrl = "/images/categories/accessories.jpg" },
                new Category { Id = 4, Name = "Dụng cụ thể thao", Description = "Dụng cụ tập luyện chuyên nghiệp", ImageUrl = "/images/categories/equipment.jpg" }
            );

            // Seed Products
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    Id = 1,
                    Name = "Giày Nike Air Max 270",
                    Description = "Giày thể thao Nike Air Max 270 với công nghệ Air Max độc đáo, thoải mái và phong cách",
                    Price = 2500000,
                    DiscountPrice = 2200000,
                    StockQuantity = 50,
                    ImageUrl = "https://cdn.storims.com/api/v2/image/resize?path=https://storage.googleapis.com/storims_cdn/storims/uploads/a57ede542c7eef38f804859080109d1d.jpeg&format=jpeg",
                    Brand = "Nike",
                    Size = "40-45",
                    Color = "Đen/Trắng",
                    IsFeatured = true,
                    CategoryId = 1
                },
                new Product
                {
                    Id = 2,
                    Name = "Áo thun thể thao Adidas",
                    Description = "Áo thun thể thao Adidas với chất liệu thấm hút mồ hôi, thoải mái khi vận động",
                    Price = 450000,
                    DiscountPrice = 380000,
                    StockQuantity = 100,
                    ImageUrl = "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/970d213c54764c0f9a2daf150099f6a7_9366/Ao_Thun_3_Soc_Classics_Adicolor_trang_IA4846_01_laydown.jpg",
                    Brand = "Adidas",
                    Size = "S-XXL",
                    Color = "Xanh dương",
                    IsFeatured = true,
                    CategoryId = 2
                },
                new Product
                {
                    Id = 3,
                    Name = "Quần short thể thao Puma",
                    Description = "Quần short thể thao Puma với thiết kế thoải mái, phù hợp cho nhiều môn thể thao",
                    Price = 350000,
                    StockQuantity = 75,
                    ImageUrl = "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_2000,h_2000/global/521351/01/fnd/VNM/fmt/png/Qu%E1%BA%A7n-short-ch%E1%BA%A1y-b%E1%BB%99-nam-2-trong-1-b%C3%A1n-ch%E1%BA%A1y",
                    Brand = "Puma",
                    Size = "S-XXL",
                    Color = "Đen",
                    CategoryId = 2
                },
                new Product
                {
                    Id = 4,
                    Name = "Bóng đá chính thức",
                    Description = "Bóng đá chính thức chất lượng cao, phù hợp cho thi đấu và tập luyện",
                    Price = 800000,
                    DiscountPrice = 650000,
                    StockQuantity = 30,
                    ImageUrl = "https://contents.mediadecathlon.com/p2571076/k$b9d48291bb6811c5899b09117d54be44/qu%E1%BA%A3-b%C3%B3ng-%C4%91%C3%A1-kh%C3%A2u-m%C3%A1y-c%E1%BB%A1-5-tr%E1%BA%AFng-kipsta-8789910.jpg?f=1920x0&format=auto",
                    Brand = "Nike",
                    Size = "Size 5",
                    Color = "Trắng/Đen",
                    CategoryId = 4
                }
            );

            // Seed Orders
            modelBuilder.Entity<Order>().HasData(
                new Order
                {
                    Id = 1,
                    CustomerName = "Nguyen Van A",
                    CustomerEmail = "a@gmail.com",
                    CustomerPhone = "0123456789",
                    ShippingAddress = "Hà Nội",
                    TotalAmount = 5000000,
                    Status = "Delivered",
                    OrderDate = new DateTime(2025, 7, 10)
                },
                new Order
                {
                    Id = 2,
                    CustomerName = "Le Thi B",
                    CustomerEmail = "b@gmail.com",
                    CustomerPhone = "0987654321",
                    ShippingAddress = "TP.HCM",
                    TotalAmount = 1200000,
                    Status = "Delivered",
                    OrderDate = new DateTime(2025, 7, 15)
                }
            );

            // Seed OrderDetails
            modelBuilder.Entity<OrderDetail>().HasData(
                new OrderDetail { Id = 1, OrderId = 1, ProductId = 1, Quantity = 2, UnitPrice = 2500000, TotalPrice = 5000000 },
                new OrderDetail { Id = 2, OrderId = 2, ProductId = 2, Quantity = 3, UnitPrice = 400000, TotalPrice = 1200000 }
            );
        }
    }
} 