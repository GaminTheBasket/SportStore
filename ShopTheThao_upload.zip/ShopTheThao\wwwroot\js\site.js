﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

// Reveal on scroll animation
function revealOnScroll() {
    const reveals = document.querySelectorAll('.reveal-on-scroll');
    for (const el of reveals) {
        const windowHeight = window.innerHeight;
        const elementTop = el.getBoundingClientRect().top;
        const elementVisible = 80;
        if (elementTop < windowHeight - elementVisible) {
            el.classList.add('visible');
        } else {
            el.classList.remove('visible');
        }
    }
}
window.addEventListener('scroll', revealOnScroll);
window.addEventListener('DOMContentLoaded', revealOnScroll);
// Tự động áp dụng cho các phần tử có class .reveal-on-scroll

// Toast notification
function showToast(type, message) {
    const icons = {
        success: '<i class="bi bi-check-circle-fill text-success toast-icon"></i>',
        error: '<i class="bi bi-x-circle-fill text-danger toast-icon"></i>',
        info: '<i class="bi bi-info-circle-fill text-primary toast-icon"></i>',
        warning: '<i class="bi bi-exclamation-triangle-fill text-warning toast-icon"></i>'
    };
    const toast = document.createElement('div');
    toast.className = `toast-message toast-${type}`;
    toast.innerHTML = `
        ${icons[type] || ''}
        <div style="flex:1;">${message}</div>
        <button class="toast-close" aria-label="Đóng">&times;</button>
    `;
    document.getElementById('toast-container').appendChild(toast);
    // Đóng khi click nút
    toast.querySelector('.toast-close').onclick = () => removeToast(toast);
    // Tự động ẩn sau 3s
    setTimeout(() => removeToast(toast), 3000);
}
function removeToast(toast) {
    toast.style.animation = 'toastOut 0.5s forwards';
    setTimeout(() => toast.remove(), 500);
}

// Loading overlay
function showLoading() {
    document.getElementById('global-loading').classList.add('active');
}
function hideLoading() {
    document.getElementById('global-loading').classList.remove('active');
}
// Tự động show loading khi submit form (trừ form có data-no-loading)
document.addEventListener('DOMContentLoaded', function() {
    document.body.addEventListener('submit', function(e) {
        if (e.target.tagName === 'FORM' && !e.target.hasAttribute('data-no-loading')) {
            showLoading();
        }
    }, true);
    // Ẩn loading khi trang load xong
    hideLoading();
});
